import { FaReply } from "react-icons/fa6";
import { useSearchParams } from "react-router-dom";

import React from 'react'
import Comments from './Comments'


function VideoAndComment() {
    const [videoId] = useSearchParams()
    const id = videoId.get("id")
    console.log(id)
    return (
        <div className='w-full md:w-4/6'>
           <div className=" flex flex-col px-8 py-5">
            <iframe className="w-full h-96" width="560" height="315" src={"https://www.youtube.com/embed/" + id} title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <h1 className='text-lg text-black font-semibold'>Dummy text title Lorem ipsum dolor sit amet text title Lorem ipsum dolor sit amet text title Lorem ipsum dolor sit amet consectetur adipisicing</h1>
                <div className="mt-4 flex justify-between">
                    <div className="items-center flex space-x-4 ">
                        <div className="place-items-center grid ">
                            <img className='h-10 rounded-full ' src="https://yt3.ggpht.com/A_3mLbY1nzH3MPjzEftkO8LK02HazD4PWy9XbwLDQ4hDkbBCla4EkcVNM0kZDTeMWqNCD4jVbA=s68-c-k-c0x00ffffff-no-rj" alt="" />
                        </div>
                        <div className=" space-y-1">
                            <p className='font-semibold text-sm'>Channel name</p>
                            <p className=' text-xs'>2.98K subscribers</p>
                        </div>
                        <button className="h-8 bg-black hover:bg-gray-900 text-white rounded-full px-3 text-sm font-semibold">
                            Subscribe</button>
                    </div>
                    <div className=" flex space-x-3">
                        <div className="">
                            <button className='px-5 text-sm py-2 rounded-l-full bg-gray-200 '>7K</button>
                            <span className="bg-gray-200 py-2 text-gray-600">|</span>
                            <button className='px-5 text-sm py-2 rounded-r-full bg-gray-200 '>7K</button>
                        </div>
                        <button className='px-5  flex items-center space-x-3 text-sm py-2 rounded-full bg-gray-200 '><FaReply className="inline" /><span>Share</span></button>
                    </div>
                </div>
            </div>
            <Comments />
        </div>
    )
}

export default VideoAndComment
