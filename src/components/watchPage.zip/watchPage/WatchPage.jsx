import React from 'react'
import SuggestedVideo from './SuggestedVideo'
import VideoAndComment from './VideoAndComment'


function WatchPage() {

  return (
    <div className='flex'>
      <VideoAndComment />
      <SuggestedVideo />
    </div>
  )
}

export default WatchPage
