import React from 'react'

function Comments() {
  return (
    <div>
      Comments
Comments
    </div>
  )
}

export default Comments

