import React from 'react'
import TrandingTopic from '../TrandingTopic'

function SuggestedVideo() {
  return (
    <div className='w-full md:w-2/6'>
      <TrandingTopic/>
    </div>
  )
}

export default SuggestedVideo
